<?php
// student/dashboard.php

// Use BASE_PATH from config.php for robust absolute paths
// Ensure config.php is loaded first as it defines BASE_PATH
require_once __DIR__ . '/../includes/config.php'; 

// Now use BASE_PATH for other includes
require_once BASE_PATH . '/includes/db.php'; 
require_once BASE_PATH . '/includes/auth.php';
require_once BASE_PATH . '/includes/functions.php';

// Verify authentication and user type
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'student') {
    header('Location: ' . SITE_URL . '/login.php');
    exit();
}

// Access the global database connection variable
global $db; 

// Obtener información del estudiante
$query = "SELECT id, nombres, apellidos, email, programa, nivel, telefono, dni, direccion 
          FROM estudiantes 
          WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $_SESSION['user_id']);
$stmt->execute();
$estudiante = $stmt->fetch(PDO::FETCH_ASSOC);

// If student user is not found (e.g., session desync with DB), handle error.
if (!$estudiante) {
    session_unset();
    session_destroy();
    header('Location: ' . SITE_URL . '/login.php?error=student_not_found');
    exit();
}

// Obtener solicitudes del estudiante
$query = "SELECT s.*, c.archivo_pdf AS url_pdf_from_db 
          FROM solicitudes s
          LEFT JOIN certificados c ON s.id = c.solicitud_id
          WHERE s.estudiante_id = :id
          ORDER BY s.fecha_solicitud DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $_SESSION['user_id']);
$stmt->execute();
$solicitudes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel del Estudiante - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style4.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Bienvenido, <?php echo htmlspecialchars($estudiante['nombres']); ?></h1>
            <nav>
                <a href="solicitar.php">Nueva Solicitud</a>
                <a href="mis-certificados.php">Mis Certificados</a>
                <a href="../logout.php">Cerrar Sesión</a>
            </nav>
        </div>
    </header>
    
    <main class="container">
        <section>
            <h2>Mis Solicitudes Recientes</h2>
            <table>
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($solicitudes)): ?>
                        <tr>
                            <td colspan="4">No hay solicitudes recientes.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($solicitudes as $solicitud): ?>
                        <tr>
                            <td><?php echo ucfirst(htmlspecialchars($solicitud['tipo'])); ?></td>
                            
                            <td>
                                <?php 
                                    if (!empty($solicitud['fecha_solicitud'])) {
                                        echo date('d/m/Y', strtotime($solicitud['fecha_solicitud']));
                                    } else {
                                        echo 'N/A'; // Or handle as appropriate
                                    }
                                ?>
                            </td>
                            
                            <td>
                                <span class="status <?php echo htmlspecialchars($solicitud['estado'] ?? 'desconocido'); ?>">
                                    <?php echo ucfirst(htmlspecialchars($solicitud['estado'] ?? 'Desconocido')); ?>
                                </span>
                            </td>
                            <td>
                                <?php if (isset($solicitud['estado']) && $solicitud['estado'] == 'aprobado' && !empty($solicitud['url_pdf_from_db'])): ?>
                                    <a href="<?php echo htmlspecialchars($solicitud['url_pdf_from_db']); ?>" class="btn" target="_blank" download>Descargar</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="actions">
                <a href="mis-certificados.php" class="btn">Ver Todos Mis Certificados</a>
            </div>
        </section>
    </main>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> CELEN - UNAP</p>
        </div>
    </footer>
</body>
</html>